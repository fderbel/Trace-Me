(function(){kango.SQLiteStorageAsync.prototype.removeDatabase()})();
